"""University Event Management Platform
Run:  pip install flask scikit-learn
      python app.py seed     # optional demo data
      python app.py          # http://127.0.0.1:5000
"""
import csv, io, random, sqlite3, sys
from datetime import date, datetime, timedelta
from flask import Flask, g, redirect, render_template_string as rts, request, Response, abort, url_for

app = Flask(__name__)
DB = "events.db"
CATS = ["Workshop", "Seminar", "Cultural", "Sports", "Hackathon"]
SCHEMA = """
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, title TEXT, category TEXT, venue TEXT,
  date TEXT, capacity INTEGER, description TEXT);
CREATE TABLE IF NOT EXISTS participants(id INTEGER PRIMARY KEY, name TEXT, email TEXT UNIQUE,
  department TEXT, year INTEGER);
CREATE TABLE IF NOT EXISTS registrations(id INTEGER PRIMARY KEY, event_id INTEGER, participant_id INTEGER,
  registered_on TEXT, attended INTEGER DEFAULT 0, UNIQUE(event_id, participant_id));
"""

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB); g.db.row_factory = sqlite3.Row
        g.db.executescript(SCHEMA)
    return g.db

@app.teardown_appcontext
def close(_):
    d = g.pop("db", None)
    if d: d.close()

# ---------- Prediction (Python/ML component) ----------
def feats(prior, year, lead, cat):
    return [prior, year, lead] + [1 if cat == c else 0 for c in CATS]

def predict_all():
    """Train logistic regression on finished events; return {reg_id: P(attend)} for upcoming ones."""
    d, today = db(), date.today().isoformat()
    rows = d.execute("""SELECT r.id, r.participant_id pid, r.attended, r.registered_on, e.date, e.category, p.year
        FROM registrations r JOIN events e ON e.id=r.event_id JOIN participants p ON p.id=r.participant_id
        ORDER BY e.date""").fetchall()
    hist, X, y, upcoming = {}, [], [], []
    for r in rows:
        h = hist.setdefault(r["pid"], [0, 0])
        prior = h[1] / h[0] if h[0] else 0.6
        lead = (date.fromisoformat(r["date"]) - date.fromisoformat(r["registered_on"])).days
        f = feats(prior, r["year"], lead, r["category"])
        if r["date"] < today:
            X.append(f); y.append(r["attended"]); h[0] += 1; h[1] += r["attended"]
        else:
            upcoming.append((r["id"], f))
    if len(set(y)) < 2 or len(y) < 30:      # not enough history -> fall back to personal rate
        return {i: f[0] for i, f in upcoming}, None
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import cross_val_score
    m = LogisticRegression(max_iter=1000).fit(X, y)
    acc = cross_val_score(LogisticRegression(max_iter=1000), X, y, cv=5).mean()
    return {i: float(m.predict_proba([f])[0][1]) for i, f in upcoming}, acc

# ---------- Templates ----------
BASE = """<!doctype html><title>UniEvents</title><style>
body{font:15px system-ui;max-width:960px;margin:20px auto;padding:0 12px;color:#222}
nav a{margin-right:14px;font-weight:600;text-decoration:none;color:#2a5bd7}
table{border-collapse:collapse;width:100%;margin:10px 0}td,th{border:1px solid #ddd;padding:6px;text-align:left}
th{background:#f3f5fa}input,select,textarea{padding:5px;margin:3px 0}button{padding:5px 12px;cursor:pointer}
.card{border:1px solid #ddd;border-radius:8px;padding:12px;margin:10px 0}.bar{background:#e5e8f0;height:10px;border-radius:5px}
.bar i{display:block;height:10px;background:#2a5bd7;border-radius:5px}.muted{color:#777}.err{color:#b00}</style>
<nav><a href="/">Dashboard</a><a href="/events">Events</a><a href="/participants">Participants</a><a href="/reports">Reports</a></nav><hr>
{{ body|safe }}"""

def page(tpl, **ctx):
    return rts(BASE, body=rts(tpl, **ctx))

# ---------- Routes ----------
@app.route("/")
def home():
    d = db()
    s = d.execute("""SELECT (SELECT COUNT(*) FROM events) ev, (SELECT COUNT(*) FROM participants) pa,
        (SELECT COUNT(*) FROM registrations) rg, (SELECT COALESCE(SUM(attended),0) FROM registrations) at""").fetchone()
    up = d.execute("""SELECT e.*, (SELECT COUNT(*) FROM registrations WHERE event_id=e.id) n FROM events e
        WHERE date>=? ORDER BY date LIMIT 5""", (date.today().isoformat(),)).fetchall()
    return page("""<h2>Dashboard</h2><div class=card>{{s.ev}} events · {{s.pa}} participants ·
      {{s.rg}} registrations · {{s.at}} attended</div><h3>Upcoming</h3>
      {% for e in up %}<div class=card><a href="/events/{{e.id}}">{{e.title}}</a> — {{e.date}}, {{e.venue}}
      <span class=muted>({{e.n}}/{{e.capacity}})</span></div>{% else %}<p class=muted>None yet.</p>{% endfor %}""", s=s, up=up)

@app.route("/events", methods=["GET", "POST"])
def events():
    d = db()
    if request.method == "POST":
        f = request.form
        d.execute("INSERT INTO events(title,category,venue,date,capacity,description) VALUES(?,?,?,?,?,?)",
                  (f["title"], f["category"], f["venue"], f["date"], int(f["capacity"]), f["description"]))
        d.commit(); return redirect("/events")
    rows = d.execute("""SELECT e.*, (SELECT COUNT(*) FROM registrations WHERE event_id=e.id) n FROM events e
        ORDER BY date DESC""").fetchall()
    return page("""<h2>Events</h2><table><tr><th>Title<th>Category<th>Date<th>Venue<th>Registered</tr>
      {% for e in rows %}<tr><td><a href="/events/{{e.id}}">{{e.title}}</a><td>{{e.category}}<td>{{e.date}}
      <td>{{e.venue}}<td>{{e.n}}/{{e.capacity}}</tr>{% endfor %}</table>
      <div class=card><h3>Create event</h3><form method=post>
      <input name=title placeholder=Title required> <select name=category>{% for c in cats %}<option>{{c}}{% endfor %}</select>
      <input name=venue placeholder=Venue required><br><input type=date name=date required>
      <input type=number name=capacity placeholder=Capacity value=50 min=1><br>
      <textarea name=description placeholder=Description cols=50></textarea><br><button>Create</button></form></div>""",
                rows=rows, cats=CATS)

@app.route("/events/<int:eid>")
def event(eid):
    d = db()
    e = d.execute("SELECT * FROM events WHERE id=?", (eid,)).fetchone() or abort(404)
    regs = d.execute("""SELECT r.*, p.name, p.email, p.department FROM registrations r
        JOIN participants p ON p.id=r.participant_id WHERE event_id=? ORDER BY p.name""", (eid,)).fetchall()
    free = d.execute("""SELECT * FROM participants WHERE id NOT IN
        (SELECT participant_id FROM registrations WHERE event_id=?) ORDER BY name""", (eid,)).fetchall()
    probs, acc = predict_all() if e["date"] >= date.today().isoformat() else ({}, None)
    expected = sum(probs.get(r["id"], 0) for r in regs)
    return page("""<h2>{{e.title}}</h2><p>{{e.category}} · {{e.date}} · {{e.venue}} · capacity {{e.capacity}}</p>
      <p>{{e.description}}</p>
      {% if upcoming %}<div class=card><b>Predicted turnout:</b> {{'%.0f'|format(expected)}} of {{regs|length}} registered
      {% if acc %}<span class=muted>(model CV accuracy {{'%.0f'|format(acc*100)}}%)</span>
      {% else %}<span class=muted>(baseline: past attendance rates)</span>{% endif %}</div>{% endif %}
      {{ msg }}
      <h3>Register participant</h3><form method=post action="/events/{{e.id}}/register">
      <select name=participant_id>{% for p in free %}<option value="{{p.id}}">{{p.name}} ({{p.email}}){% endfor %}</select>
      <button>Register</button></form>
      <h3>Registrations & attendance</h3><table><tr><th>Name<th>Dept<th>P(attend)<th>Attendance<th>Certificate</tr>
      {% for r in regs %}<tr><td>{{r.name}}<td>{{r.department}}
      <td>{% if r.id in probs %}{{'%.0f'|format(probs[r.id]*100)}}%{% else %}–{% endif %}
      <td><form method=post action="/attendance/{{r.id}}" style="margin:0"><button>{{'✔ Present' if r.attended else 'Mark present'}}</button></form>
      <td>{% if r.attended %}<a href="/certificate/{{r.id}}">View</a>{% else %}<span class=muted>–</span>{% endif %}</tr>{% endfor %}</table>""",
                e=e, regs=regs, free=free, probs=probs, acc=acc, expected=expected,
                upcoming=e["date"] >= date.today().isoformat(), msg=request.args.get("msg", ""))

@app.route("/events/<int:eid>/register", methods=["POST"])
def register(eid):
    d = db()
    e = d.execute("SELECT * FROM events WHERE id=?", (eid,)).fetchone() or abort(404)
    n = d.execute("SELECT COUNT(*) FROM registrations WHERE event_id=?", (eid,)).fetchone()[0]
    if n >= e["capacity"]:
        return redirect(url_for("event", eid=eid, msg="Event is full."))
    try:
        d.execute("INSERT INTO registrations(event_id,participant_id,registered_on) VALUES(?,?,?)",
                  (eid, request.form["participant_id"], date.today().isoformat())); d.commit()
    except sqlite3.IntegrityError:
        pass
    return redirect(url_for("event", eid=eid))

@app.route("/attendance/<int:rid>", methods=["POST"])
def attendance(rid):
    d = db()
    r = d.execute("SELECT event_id, attended FROM registrations WHERE id=?", (rid,)).fetchone() or abort(404)
    d.execute("UPDATE registrations SET attended=? WHERE id=?", (1 - r["attended"], rid)); d.commit()
    return redirect(url_for("event", eid=r["event_id"]))

@app.route("/participants", methods=["GET", "POST"])
def participants():
    d, err = db(), ""
    if request.method == "POST":
        f = request.form
        try:
            d.execute("INSERT INTO participants(name,email,department,year) VALUES(?,?,?,?)",
                      (f["name"], f["email"], f["department"], int(f["year"]))); d.commit()
        except sqlite3.IntegrityError:
            err = "Email already registered."
    rows = d.execute("""SELECT p.*, COUNT(r.id) reg, COALESCE(SUM(r.attended),0) att FROM participants p
        LEFT JOIN registrations r ON r.participant_id=p.id GROUP BY p.id ORDER BY p.name""").fetchall()
    return page("""<h2>Participants</h2><p class=err>{{err}}</p><table><tr><th>Name<th>Email<th>Dept<th>Year<th>Registered<th>Attended</tr>
      {% for p in rows %}<tr><td>{{p.name}}<td>{{p.email}}<td>{{p.department}}<td>{{p.year}}<td>{{p.reg}}<td>{{p.att}}</tr>{% endfor %}</table>
      <div class=card><h3>Add participant</h3><form method=post><input name=name placeholder=Name required>
      <input type=email name=email placeholder=Email required><input name=department placeholder=Department required>
      <input type=number name=year min=1 max=6 value=1><button>Add</button></form></div>""", rows=rows, err=err)

@app.route("/certificate/<int:rid>")
def certificate(rid):
    r = db().execute("""SELECT r.id, r.attended, p.name, e.title, e.date FROM registrations r
        JOIN participants p ON p.id=r.participant_id JOIN events e ON e.id=r.event_id WHERE r.id=?""", (rid,)).fetchone()
    if not r or not r["attended"]:
        abort(404)
    return rts("""<!doctype html><title>Certificate</title><body style="font-family:Georgia,serif;text-align:center;
      border:10px double #2a5bd7;margin:30px;padding:60px"><h1 style="font-size:42px">Certificate of Participation</h1>
      <p>This is to certify that</p><h2 style="font-size:34px">{{r.name}}</h2>
      <p>attended <b>{{r.title}}</b> held on {{r.date}}.</p>
      <p style="margin-top:50px;color:#777">Verification code: CERT-{{'%06d'|format(r.id)}} · <a href="javascript:print()">Print</a></p>""", r=r)

@app.route("/reports")
def reports():
    d = db()
    rows = d.execute("""SELECT e.id, e.title, e.category, e.date, e.capacity, COUNT(r.id) reg,
        COALESCE(SUM(r.attended),0) att FROM events e LEFT JOIN registrations r ON r.event_id=e.id
        GROUP BY e.id ORDER BY e.date DESC""").fetchall()
    cat = d.execute("""SELECT e.category, COUNT(r.id) reg, COALESCE(SUM(r.attended),0) att FROM events e
        LEFT JOIN registrations r ON r.event_id=e.id WHERE e.date<? GROUP BY e.category""",
                    (date.today().isoformat(),)).fetchall()
    dept = d.execute("""SELECT p.department, COUNT(*) reg, SUM(r.attended) att FROM registrations r
        JOIN participants p ON p.id=r.participant_id GROUP BY p.department ORDER BY reg DESC""").fetchall()
    return page("""<h2>Reports</h2><p><a href="/reports.csv">Download CSV</a></p>
      <table><tr><th>Event<th>Date<th>Registered<th>Attended<th>Fill<th>Attendance rate</tr>
      {% for r in rows %}<tr><td>{{r.title}}<td>{{r.date}}<td>{{r.reg}}<td>{{r.att}}
      <td><div class=bar><i style="width:{{100*r.reg//r.capacity}}%"></i></div>
      <td>{{ '%.0f'|format(100*r.att/r.reg) ~ '%' if r.reg else '–' }}</tr>{% endfor %}</table>
      <h3>By category (past events)</h3><table><tr><th>Category<th>Registered<th>Attended</tr>
      {% for c in cat %}<tr><td>{{c.category}}<td>{{c.reg}}<td>{{c.att}}</tr>{% endfor %}</table>
      <h3>By department</h3><table><tr><th>Department<th>Registered<th>Attended</tr>
      {% for c in dept %}<tr><td>{{c.department}}<td>{{c.reg}}<td>{{c.att}}</tr>{% endfor %}</table>""",
                rows=rows, cat=cat, dept=dept)

@app.route("/reports.csv")
def reports_csv():
    rows = db().execute("""SELECT e.title, e.category, e.date, p.name, p.email, p.department,
        r.attended FROM registrations r JOIN events e ON e.id=r.event_id
        JOIN participants p ON p.id=r.participant_id ORDER BY e.date, p.name""").fetchall()
    out = io.StringIO(); w = csv.writer(out)
    w.writerow(["event", "category", "date", "name", "email", "department", "attended"])
    w.writerows([tuple(r) for r in rows])
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=event_report.csv"})

# ---------- Demo data ----------
def seed():
    random.seed(1)
    d = sqlite3.connect(DB); d.executescript(SCHEMA)
    depts = ["CSE", "ECE", "Mech", "Civil", "MBA"]
    for i in range(60):
        d.execute("INSERT OR IGNORE INTO participants(name,email,department,year) VALUES(?,?,?,?)",
                  (f"Student {i+1}", f"s{i+1}@uni.edu", random.choice(depts), random.randint(1, 4)))
    rel = {i: random.uniform(.3, .95) for i in range(1, 61)}      # hidden reliability drives attendance
    today = date.today()
    for k in range(15):
        past = k < 12
        day = today - timedelta(days=15 * (12 - k)) if past else today + timedelta(days=5 * (k - 11))
        cat = random.choice(CATS)
        d.execute("INSERT INTO events(title,category,venue,date,capacity,description) VALUES(?,?,?,?,?,?)",
                  (f"{cat} #{k+1}", cat, random.choice(["Hall A", "Auditorium", "Lab 2"]), day.isoformat(), 40, "Demo event"))
        for pid in random.sample(range(1, 61), 30):
            lead = random.randint(1, 14)
            att = int(past and random.random() < rel[pid] - 0.01 * lead)
            d.execute("INSERT INTO registrations(event_id,participant_id,registered_on,attended) VALUES(?,?,?,?)",
                      (k + 1, pid, (day - timedelta(days=lead)).isoformat(), att))
    d.commit(); print("Seeded.")

if __name__ == "__main__":
    seed() if "seed" in sys.argv else app.run(debug=True)
